
import {StyleSheet,Dimensions} from 'react-native';

const styles = StyleSheet.create({
    tela:{
        flex: 1,  
      },
    
      container:{
        flex: 1,
        backgroundColor:"#FFFFFF",
      },

      containerMap:{
        ...StyleSheet.absoluteFillObject,
      },    

      cabecalho:{
        width:"100%",
        height:20,
        position:'absolute',
        zIndex:10,
        backgroundColor:"#6666FF",
      },

      containerAnimation:{
        position:"absolute",
        flex:1,
        width:"100%",
      },

      Voltar:{
        zIndex:15,
        position:"absolute",

        top:"5%",
        
      },

      BotaoVoltar:{
        width:40,
        height:40,
        justifyContent:"center",
        alignItems:'center',
        flex:1,
        left:20,
        top:20,
        borderRadius:10,
        textAlign:"center",
        padding:10,
        paddingTop:6,

        borderWidth:1,

        shadowColor: '#000',
        shadowOffset: { width: 1, height: 1 },
        shadowOpacity: 0.3,
        shadowRadius: 5,

        backgroundColor:"#FFF",
      },

      buttonStyle: {
        padding: 10,
        margin: 5,
        borderRadius: 15,
        backgroundColor: '#117864',
        textAlign: 'center',
        color: 'white',
        fontSize: 20,
    },


      buttonStyle: {
        padding:5,
        margin: 5,
        textAlign: 'center',
        color: 'white',
        fontSize: 20,
    },


    contentButton:{
      zIndex:5,  
        position:"absolute",
        width:"100%",
        height:100,
        top:"82%",
        flex:1,
        justifyContent:'center',
        alignItems:'center',
        
        padding:20
    },

    button:{
      backgroundColor: '#6666FF',
      borderRadius:5,
      width:"90%",
      borderColor:"#002F9D",
    },


    tittle:{
        //fontFamily:"Arial",
        fontSize:20,
        fontWeight:'bold',
        textAlign:"center",
        color:"#6666FF",
        marginBottom:15,

    },

    subtittle:{
        //fontFamily:"Arial",
        fontSize:15,
        textAlign:"center",
        marginBottom:5,
        
    },

    mapStyle: {
        width: Dimensions.get('window').width,
        height: Dimensions.get('window').height,
        ...StyleSheet.absoluteFillObject,
      },
  });
  
  export default styles;