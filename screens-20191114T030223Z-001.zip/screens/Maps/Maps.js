import React, {Component} from 'react';
import { View,
    Animated,
    Text,
    TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Circle } from 'react-native-maps';
import styles from './Style';
import { isPointWithinRadius } from 'geolib';

export default class Maps extends Component{
  
  constructor(props) {
    super(props);
    this.state = {
      
      markers: 
        {
          coordinate: {
            latitude: -22.90110,
            longitude: -47.05787,
          }
        }
      ,
      region: {
        latitude: -22.90110,
        longitude: -47.05787,
        latitudeDelta: 0.005,
        longitudeDelta: 0.005,
      },
      locationChosen: false,
      startlocate: false,
      data: '',
      check: "DENTRO"
      
    }

    this.voltar = this.voltar.bind(this);

  }

  voltar(){
    let varNome =  this.props.navigation.state.params.varNome ;
    let varEmail =  this.props.navigation.state.params.varEmail ;
    this.props.navigation.navigate('Menu',{varNome,varEmail});
  }

  componentDidMount() {
    this.timerID = setInterval(
      () => this.fetchNewCoord(),
      5000
    );
  }

  componentWillUnmount() {
    clearInterval(this.timerID);
  }

  changeMarker = () => {
   
      if(this.state.startlocate) {
  
        if(this.state.region.latitude != 0
          && this.state.region.longitude != 0) {
           
            this.setState({
              region: {
                latitude: this.state.region.latitude,
                longitude: this.state.region.longitude,
                latitudeDelta: 0.005,
                longitudeDelta: 0.005,
              },
              locationChosen: true
            }, () => {
              
              this.map.animateToRegion({
                latitude: this.state.region.latitude,
                longitude: this.state.region.longitude,
                latitudeDelta: 0.005,
                longitudeDelta: 0.005,
              });
            })
             
            let check = isPointWithinRadius(this.state.region, this.state.region, 20); 
            if(!check){
              
              this.setState({check: "FORA"})
            }else {
              
              this.setState({check: "DENTRO"})
            }
            
          }
          else {
             
            this.setState({startlocate: false})

            alert("Coordenadas do localizador ainda não foram definidas");
          }
          
      }

  }

  fetchNewCoord = () => {

      fetch('http://192.168.15.20/aps_server/get_coord.php', {
      
        method: 'POST',
        headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        },
        body: JSON.stringify({
  
          name: this.props.navigation.state.params.varName,
          email: this.props.navigation.state.params.varEmail
          
        })
      })
      .then(response => response.text())
      .then((raspCoords) => {


         this.setState({
           region: {
             latitude: parseFloat(raspCoords.split("&")[0]),
             longitude: parseFloat(raspCoords.split("&")[1]),
             latitudeDelta: 0.005,
             longitudeDelta: 0.005,
           } // TENTAR COLOCAR O CÓDIGO DO CHANGE AQUI
         }, () => {this.changeMarker()});
       });
   
     
  }


  buttonActionHandler = () => {
    this.setState({startlocate: true}, () => {
      this.fetchNewCoord()
    });
  }

  render() {

    let marker = null;
    let circle = null; 

    if (this.state.locationChosen) {
      marker = <MapView.Marker coordinate={this.state.region} />;
      circle = <Circle center={
        {latitude: this.state.region.latitude,
        longitude: this.state.region.longitude,}
                        } 
                        radius={20}
               />
    }

return(
    /* Container da Tela */
    <View style={styles.tela}>  
        <View style={styles.cabecalho}/>         
        <View style={styles.container}>  

            <View style={styles.Voltar}> 
                <TouchableOpacity style={styles.BotaoVoltar} onPress={(this.voltar)}>
                    <Ionicons name="ios-arrow-back" size={27}/>      
                </TouchableOpacity>
            </View>
            
            <View style={styles.containerMap} >
              <MapView
                style={styles.mapStyle}
                ref={map => this.map = map}
                initialRegion={this.state.region}
              >
              {marker}
              {circle}
              </MapView> 
            </View>

              <View style={styles.contentButton}>
                  <Text style={styles.tittle}> DISPOSITIVO {this.state.check} DA AREA</Text>

                  <TouchableOpacity onPress={this.buttonActionHandler} style={styles.button} >
                      <Text style={styles.buttonStyle}>Localizar</Text>
                  </TouchableOpacity>
              </View>
        </View>
    </View>        
        );
    }
}